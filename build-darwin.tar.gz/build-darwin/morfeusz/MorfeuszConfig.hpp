/* 
 * File:   morfeusz_config.hpp.in
 * Author: mlenart
 *
 * Created on November 29, 2013, 10:03 PM
 */

#define Morfeusz_VERSION_MAJOR 0
#define Morfeusz_VERSION_MINOR 1

